import "./repositories/UserRepositoryConfig";
//Import all repository configs for dependency injection

export { container } from "tsyringe";
